import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';

// UrCare brand mark: a heart outline with an embedded circuit trace (AI/digital health)
// and a medical cross — matches the app's favicon and every in-app logo placement.
export const BrandMark: React.FC<{ className?: string }> = ({ className = '' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className}>
    <path
      d="M24 41C24 41 6 29.5 6 15.5C6 8.6 11.2 4 17 4C20.3 4 22.7 5.9 24 8.6C25.3 5.9 27.7 4 31 4C36.8 4 42 8.6 42 15.5C42 29.5 24 41 24 41Z"
      stroke="currentColor"
      strokeWidth="3.6"
      strokeLinejoin="round"
      strokeLinecap="round"
    />
    <path
      d="M13 26H15.5L18.5 29.5H21.5"
      stroke="currentColor"
      strokeWidth="2.4"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <circle cx="21.8" cy="29.5" r="1.9" fill="currentColor" />
    <circle cx="18.5" cy="23.2" r="1.9" fill="currentColor" />
    <path d="M13 26L15.5 23.2H18.5" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
    <path
      d="M33 15H37V19H33V23H29V19H25V15H29V11H33V15Z"
      fill="currentColor"
    />
  </svg>
);

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
  className?: string;
  /** Tighter subtitle sizing/tracking for cramped spots (e.g. the mobile
   *  top header) so "True Healthcare Platform" never pushes into nearby
   *  buttons — it shrinks and ellipsizes instead of colliding. */
  compact?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  showSubtitle = true,
  className = '',
  compact = false,
}) => {
  const { theme } = useTheme();
  const isDark = theme === 'dark';
  // Some mobile browsers/first paints can fail to fetch the PNG (slow network,
  // aggressive image caching, etc.). Fall back to the inline vector mark so the
  // logo never silently collapses to just the alt text on any device.
  const [imgFailed, setImgFailed] = useState(false);

  const iconSizes = {
    sm: 'w-11 h-11',
    md: 'w-14 h-14',
    lg: 'w-20 h-20',
    xl: 'w-24 h-24',
  };

  const titleSizes = {
    sm: 'text-sm tracking-tight',
    md: 'text-lg tracking-tight',
    lg: 'text-2xl tracking-tighter',
    xl: 'text-3xl tracking-tighter',
  };

  const subSizes = {
    sm: 'text-[9px] tracking-wider',
    md: 'text-[10px] tracking-widest',
    lg: 'text-xs tracking-widest',
    xl: 'text-xs tracking-widest',
  };

  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      {/* Brand Icon: real UrCare logo artwork, no plate/border — just the mark itself.
          If the PNG ever fails to load (flaky mobile network, cache miss, etc.),
          fall back to the inline vector mark so the icon is never just blank/text. */}
      {imgFailed ? (
        <BrandMark className={`${iconSizes[size]} shrink-0 text-emerald-600`} />
      ) : (
        <img
          src="/UrCare.png"
          alt="UrCare"
          width={96}
          height={96}
          decoding="async"
          onError={() => setImgFailed(true)}
          className={`${iconSizes[size]} shrink-0 object-contain`}
        />
      )}

      {/* Brand Typography */}
      <div className="flex flex-col text-left min-w-0">
        <div className={`font-black flex items-center tracking-tight ${titleSizes[size]}`}>
          <span className={isDark ? 'text-white' : 'text-zinc-950'}>Ur</span>
          <span className="text-emerald-500">Care</span>
        </div>
        {showSubtitle && (
          <span
            className={`block font-bold uppercase text-emerald-700/80 ${
              compact
                ? 'whitespace-normal leading-[1.15] text-[7px] tracking-normal'
                : `truncate tracking-[0.14em] ${subSizes[size]}`
            }`}
          >
            True Healthcare Platform
          </span>
        )}
      </div>
    </div>
  );
};
